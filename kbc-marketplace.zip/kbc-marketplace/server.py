"""Local marketplace application: stdlib HTTP + SQLite. Python 3.11+.

This server intentionally has no live payment integration. DEMO orders record
simulated payments; non-demo checkout is rejected until a provider is integrated.
"""
from __future__ import annotations

import argparse
import base64
from collections import defaultdict, deque
from contextlib import contextmanager
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
from urllib.parse import urlsplit, unquote
import uuid

ROOT = Path(__file__).resolve().parent
MAX_FILE = 5 * 1024 * 1024
MAX_BODY = 8 * 1024 * 1024
SESSION_MS = 7 * 24 * 60 * 60 * 1000
WEIGHTS = {'view': 1, 'search': 1.2, 'cart': 2.4, 'deal': 3.4, 'fav': 1.6}


def now():
    return int(time.time() * 1000)


def new_id(prefix='id'):
    return prefix + '_' + uuid.uuid4().hex


class APIError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


def require(condition, message, status=400):
    if not condition:
        raise APIError(status, message)


def text(data, name, minimum=1, maximum=500):
    value = data.get(name)
    require(isinstance(value, str), name + ' must be text')
    value = value.strip()
    require(minimum <= len(value) <= maximum, name + ' has an invalid length')
    return value


def integer(data, name, low, high):
    value = data.get(name)
    require(type(value) is int and low <= value <= high, name + ' has an invalid value')
    return value


def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384,
                          r=8, p=1, maxmem=64*1024*1024).hex()


def create_user(db, email, name, password):
    uid, salt, stamp = new_id('u'), secrets.token_hex(16), now()
    db.execute('INSERT INTO users VALUES (?,?,?,?,?,?,?)',
               (uid, email.lower(), name, None, 'active', stamp, stamp))
    db.execute('INSERT INTO auth_credentials VALUES (?,?,?)',
               (uid, salt, password_hash(password, salt)))
    db.execute('INSERT INTO user_settings (user_id) VALUES (?)', (uid,))
    return uid


def initialize(path: Path, demo=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if sqlite3.sqlite_version_info < (3, 37, 0):
        raise RuntimeError('SQLite 3.37+ is required')
    with sqlite3.connect(path) as db:
        db.execute('PRAGMA foreign_keys=ON')
        exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='schema_migrations'").fetchone()
        if not exists:
            db.executescript((ROOT/'schema.sql').read_text())
        if not db.execute('SELECT 1 FROM schema_migrations WHERE version=2').fetchone():
            db.executescript((ROOT/'migration_002.sql').read_text())
        # A seeded database never changes mode merely because a flag changes.
        if db.execute("SELECT 1 FROM app_meta WHERE key='demo_mode'").fetchone():
            return
        db.execute('INSERT INTO app_meta VALUES (?,?)', ('demo_mode', '1' if demo else '0'))
        seed = json.loads((ROOT/'seed.json').read_text())
        for c in seed['categories']:
            db.execute('INSERT INTO categories VALUES (?,?,?,?,?,?)',
                       (c['id'], None, c['en'], c['fr'], c['nl'], c['ic']))
        if not demo:
            return
        buyer = create_user(db, 'buyer@demo.local', 'Demo Buyer', 'DemoBuyer2026!')
        merchant = create_user(db, 'seller@demo.local', 'Demo Merchant', 'DemoSeller2026!')
        stamp = now()
        for s in seed['sellers']:
            db.execute('''INSERT INTO businesses
                (id,legal_name,trading_name,business_type,country_code,registration_number,
                 vat_status,verification_status,verified_at_ms,verification_reference,city,
                 created_at_ms,updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (s['id'], s['name']+' (fictional demo)', s['name'], 'company', 'BE',
                 'DEMO-'+s['id'], 'unknown', 'verified', stamp, 'DEMO ONLY — not checked',
                 s['city'], stamp, stamp))
        # The demo seller operates TechNova only. Other shops remain fixtures.
        db.execute('INSERT INTO business_members VALUES (?,?,?)', ('s1', merchant, 'owner'))
        db.execute("UPDATE user_settings SET preferred_role='seller' WHERE user_id=?", (merchant,))
        for p in seed['products']:
            d = p.get('d', {})
            db.execute('INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                       (p['id'], p['cat'], p['brand'], p['title'], d.get('en',''),
                        d.get('fr'), d.get('nl'), p['emoji'], 'active', stamp, stamp))
            for k, value in p.get('specs', []):
                db.execute('INSERT INTO product_specs VALUES (?,?,?)', (p['id'], k, value))
            for i, v in enumerate(p.get('variants', [])):
                db.execute('INSERT INTO product_variants VALUES (?,?,?)',
                           (p['id']+'-v'+str(i), p['id'], v))
            for l in seed['listings'][p['id']]:
                db.execute('''INSERT INTO listings
                    (id,product_id,business_id,price_minor,stock,condition,delivery_days,
                     status,created_at_ms,updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?)''',
                    (l['id'], p['id'], l['sellerId'], round(l['price']*100), l['stock'],
                     l['condition'], l['deliveryDays'], 'published', stamp, stamp))


class Marketplace:
    def __init__(self, db_path):
        self.path = Path(db_path)

    @contextmanager
    def connection(self, write=False):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA busy_timeout=15000')
        try:
            if write:
                db.execute('BEGIN IMMEDIATE')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def demo(db):
        row = db.execute("SELECT value FROM app_meta WHERE key='demo_mode'").fetchone()
        return bool(row and row[0] == '1')

    @staticmethod
    def membership(db, uid, bid):
        return db.execute('SELECT role FROM business_members WHERE user_id=? AND business_id=?',
                          (uid, bid)).fetchone()

    @staticmethod
    def session(db, token):
        if not token:
            return None
        return db.execute('''SELECT s.*,u.display_name,u.email FROM auth_sessions s
              JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at_ms>?
              AND u.status='active' ''', (hashlib.sha256(token.encode()).hexdigest(), now())).fetchone()

    @staticmethod
    def new_session(db, uid):
        token, csrf, stamp = secrets.token_urlsafe(32), secrets.token_urlsafe(24), now()
        db.execute('DELETE FROM auth_sessions WHERE expires_at_ms<=?', (stamp,))
        db.execute('INSERT INTO auth_sessions VALUES (?,?,?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(), uid, csrf, stamp, stamp+SESSION_MS))
        return token, csrf

    @staticmethod
    def audit(db, uid, action, kind, eid):
        db.execute('INSERT INTO audit_events VALUES (?,?,?,?,?,?,?)',
                   (new_id('audit'), uid, action, kind, eid, None, now()))

    def catalog(self, db, uid=None):
        # Retain objects needed for private orders/chats after a listing is paused.
        public = {r[0] for r in db.execute('''SELECT DISTINCT p.id FROM products p
             JOIN listings l ON l.product_id=p.id JOIN businesses b ON b.id=l.business_id
             WHERE p.status='active' AND l.status='published' AND b.verification_status='verified' ''')}
        extra = set()
        if uid:
            for row in db.execute('''SELECT DISTINCT l.product_id FROM listings l
                  LEFT JOIN business_members m ON m.business_id=l.business_id
                  LEFT JOIN order_items i ON i.listing_id=l.id
                  LEFT JOIN orders o ON o.id=i.order_id WHERE m.user_id=? OR o.buyer_id=?''', (uid,uid)):
                extra.add(row[0])
            extra.update(r[0] for r in db.execute('''SELECT c.product_id FROM conversations c
                 LEFT JOIN conversation_participants cp ON cp.conversation_id=c.id
                 WHERE cp.user_id=? AND c.product_id IS NOT NULL''', (uid,)))
        products = []
        for p in db.execute('SELECT * FROM products'):
            if p['id'] not in public | extra:
                continue
            stats = db.execute('''SELECT AVG(r.rating),COUNT(r.id) FROM reviews r
                  JOIN order_items i ON i.id=r.order_item_id JOIN listings l ON l.id=i.listing_id
                  WHERE l.product_id=?''',(p['id'],)).fetchone()
            prices = db.execute("SELECT MIN(price_minor) FROM listings WHERE product_id=? AND status='published'", (p['id'],)).fetchone()
            first_price = db.execute('SELECT MIN(price_minor) FROM listings WHERE product_id=?', (p['id'],)).fetchone()[0]
            photo = db.execute('SELECT file_id FROM product_files WHERE product_id=? ORDER BY position LIMIT 1',(p['id'],)).fetchone()
            products.append(dict(id=p['id'],cat=p['category_id'],brand=p['brand'],title=p['title'],
                d=dict(en=p['description_en'],fr=p['description_fr'],nl=p['description_nl']),
                emoji=p['emoji'] or '📦', price=(prices[0] or first_price or 0)/100,
                rating=stats[0] or 0,reviews=stats[1],catalogActive=p['id'] in public,
                image='/api/files/'+photo[0] if photo else None,
                variants=[v[0] for v in db.execute('SELECT label FROM product_variants WHERE product_id=?',(p['id'],))] or ['📦'],
                specs=[list(v) for v in db.execute('SELECT name,value FROM product_specs WHERE product_id=?',(p['id'],))]))
        sellers=[]
        for b in db.execute('SELECT * FROM businesses'):
            stats=db.execute('''SELECT AVG(r.rating),COUNT(r.id) FROM reviews r JOIN order_items i
                 ON i.id=r.order_item_id WHERE i.business_id=?''',(b['id'],)).fetchone()
            sellers.append(dict(id=b['id'],name=b['trading_name'],legalName=b['legal_name'],
                city=b['city'] or '',rating=stats[0] or 0,reviews=stats[1],
                businessType=b['business_type'],registrationNumber=b['registration_number'],
                vatNumber=b['vat_number'],verificationStatus=b['verification_status'],
                demo=b['registration_number'].startswith('DEMO-')))
        listings={p['id']:[] for p in products}
        for l in db.execute('SELECT * FROM listings ORDER BY price_minor'):
            if l['product_id'] not in listings:
                continue
            if l['status']!='published' and not (uid and (self.membership(db,uid,l['business_id']) or
                db.execute('SELECT 1 FROM order_items i JOIN orders o ON o.id=i.order_id WHERE i.listing_id=? AND o.buyer_id=?',(l['id'],uid)).fetchone())):
                continue
            listings[l['product_id']].append(dict(id=l['id'],productId=l['product_id'],sellerId=l['business_id'],
                price=l['price_minor']/100,deliveryDays=l['delivery_days'],bonusPct=0,
                condition=l['condition'],stock=l['stock'],status=l['status']))
        return dict(products=products,sellers=sellers,listings=listings)

    @staticmethod
    def activity(db,uid):
        return [dict(id=r['id'],type=r['event_type'],productId=r['product_id'],cat=r['category_id'],
                brand=r['brand_snapshot'],price=r['price_minor']/100 if r['price_minor'] is not None else None,
                q=r['search_query'],ts=r['created_at_ms']) for r in db.execute(
                'SELECT * FROM activity_events WHERE user_id=? ORDER BY created_at_ms DESC,rowid DESC LIMIT 80',(uid,))]

    @staticmethod
    def rank(products,events):
        cats,brands,prices=defaultdict(float),defaultdict(float),[]
        for i,e in enumerate(events):
            w=WEIGHTS[e['type']]*max(.35,1-i*.012)
            if e.get('cat'): cats[e['cat']]+=w
            if e.get('brand'): brands[e['brand']]+=w
            if e.get('price') is not None and e['type'] in ('view','cart','deal'): prices.append(e['price'])
        avg=sum(prices)/len(prices) if prices else 0
        recent={e['productId'] for e in [e for e in events if e['type']=='view'][:3]}
        ranked=[]
        for p in products:
            if not p['catalogActive']: continue
            if not events:
                score=p['rating']*math.log(p['reviews']+1)
            else:
                score=p['rating']*.6+cats[p['cat']]*3.2+brands[p['brand']]*2.2
                if avg: score+=max(0,1.6-abs(p['price']-avg)/max(avg,150)*1.6)
                if p['id'] in recent: score-=1.5
            ranked.append(dict(productId=p['id'],score=round(score,6),reason='Your activity' if events else 'Catalogue'))
        return sorted(ranked,key=lambda r:-r['score'])[:10]

    def log_event(self,db,uid,kind,pid=None,category=None,query=None):
        enabled=db.execute('SELECT personalization_enabled FROM user_settings WHERE user_id=?',(uid,)).fetchone()
        if not enabled or not enabled[0]: return
        p=db.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone() if pid else None
        if pid: require(p is not None,'Unknown product',404)
        if category: require(db.execute('SELECT 1 FROM categories WHERE id=?',(category,)).fetchone(),'Unknown category')
        price=db.execute("SELECT MIN(price_minor) FROM listings WHERE product_id=? AND status='published'",(pid,)).fetchone()[0] if p else None
        db.execute('INSERT INTO activity_events VALUES (?,?,?,?,?,?,?,?,?)',
                   (new_id('ev'),uid,kind,pid,p['category_id'] if p else category,
                    p['brand'] if p else None,price,query,now()))
        # Record an auditable snapshot of a rules-based recommendation run.
        ranking=self.rank(self.catalog(db,uid)['products'],self.activity(db,uid))
        rid=new_id('rec')
        db.execute('INSERT INTO recommendation_runs VALUES (?,?,?,?)',(rid,uid,'heuristic-v1',now()))
        for i,r in enumerate(ranking,1):
            db.execute('INSERT INTO recommendation_items VALUES (?,?,?,?,?)',(rid,r['productId'],i,r['score'],r['reason']))

    def bootstrap(self,db,session):
        uid=session['user_id'] if session else None
        catalog=self.catalog(db,uid)
        categories=[dict(id=c['id'],en=c['name_en'],fr=c['name_fr'] or c['name_en'],
            nl=c['name_nl'] or c['name_en'],ic=c['icon'],g='gb') for c in db.execute('SELECT * FROM categories')]
        state=dict(lang='en',role='buyer',theme=None,cart=[],favs=[],convs=[],deals=[],activity=[])
        user=None;businesses=[];owned=[];documents=[];addresses=[]
        if uid:
            settings=db.execute('SELECT * FROM user_settings WHERE user_id=?',(uid,)).fetchone()
            state.update(lang=settings['language'],role=settings['preferred_role'],theme=settings['theme'])
            user=dict(id=uid,name=session['display_name'],email=session['email'],personalization=bool(settings['personalization_enabled']))
            state['cart']=[dict(lid=r['listing_id'],qty=r['quantity'],vi=0) for r in db.execute('SELECT * FROM cart_items WHERE user_id=?',(uid,))]
            state['favs']=[r[0] for r in db.execute('SELECT product_id FROM favorites WHERE user_id=?',(uid,))]
            state['activity']=self.activity(db,uid)
            businesses=[dict(r) for r in db.execute('''SELECT b.*,m.role FROM businesses b JOIN business_members m
                ON m.business_id=b.id WHERE m.user_id=?''',(uid,))]
            owned=[dict(r) for r in db.execute('''SELECT l.*,p.title FROM listings l JOIN products p ON p.id=l.product_id
                JOIN business_members m ON m.business_id=l.business_id WHERE m.user_id=? ORDER BY l.created_at_ms DESC''',(uid,))]
            documents=[dict(r) for r in db.execute('''SELECT bd.*,f.original_name FROM business_documents bd
                JOIN files f ON f.id=bd.file_id JOIN business_members m ON m.business_id=bd.business_id
                WHERE m.user_id=?''',(uid,))]
            addresses=[dict(r) for r in db.execute('SELECT * FROM addresses WHERE user_id=?',(uid,))]
            for c in db.execute('''SELECT DISTINCT c.* FROM conversations c JOIN conversation_participants cp
                   ON cp.conversation_id=c.id WHERE cp.user_id=? ORDER BY c.created_at_ms DESC''',(uid,)):
                is_buyer=c['buyer_id']==uid
                if (state['role']=='buyer') != is_buyer: continue
                last=db.execute('SELECT last_read_at_ms FROM conversation_participants WHERE conversation_id=? AND user_id=?',(c['id'],uid)).fetchone()[0] or 0
                msgs=[];unread=0
                for m in db.execute('SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at_ms,rowid',(c['id'],)):
                    sender=m['sender_user_id']
                    if sender and sender!=uid and m['created_at_ms']>last: unread+=1
                    attachments=[dict(id=f['id'],name=f['original_name']) for f in db.execute(
                        'SELECT f.* FROM files f JOIN message_files mf ON mf.file_id=f.id WHERE mf.message_id=?',(m['id'],))]
                    msgs.append(dict(id=m['id'],type=m['kind'],text=m['body'],ts=m['created_at_ms'],
                        mine=sender==uid,fromRole='sys' if not sender else 'buyer' if sender==c['buyer_id'] else 'seller',files=attachments))
                state['convs'].append(dict(id=c['id'],sellerId=c['business_id'],productId=c['product_id'],unread=unread,messages=msgs,
                    buyerName=db.execute('SELECT display_name FROM users WHERE id=?',(c['buyer_id'],)).fetchone()[0]))
            if state['role']=='seller':
                orders=db.execute('''SELECT o.* FROM orders o JOIN business_members m ON m.business_id=o.business_id
                         WHERE m.user_id=? ORDER BY o.created_at_ms DESC''',(uid,)).fetchall()
            else:
                orders=db.execute('SELECT * FROM orders WHERE buyer_id=? ORDER BY created_at_ms DESC',(uid,)).fetchall()
            for o in orders:
                deal=db.execute('SELECT * FROM secure_deals WHERE order_id=?',(o['id'],)).fetchone()
                items=[dict(r) for r in db.execute('SELECT * FROM order_items WHERE order_id=?',(o['id'],))]
                total=db.execute('SELECT total_minor FROM order_totals WHERE order_id=?',(o['id'],)).fetchone()[0]
                history=[dict(r) for r in db.execute('SELECT * FROM order_status_history WHERE order_id=? ORDER BY created_at_ms',(o['id'],))]
                payments=[dict(r) for r in db.execute('SELECT id,kind,amount_minor,status,provider FROM payment_transactions WHERE order_id=?',(o['id'],))]
                reviews=[dict(r) for r in db.execute('''SELECT r.* FROM reviews r JOIN order_items i ON i.id=r.order_item_id
                         WHERE i.order_id=?''',(o['id'],))]
                shipment=db.execute('SELECT * FROM shipments WHERE order_id=?',(o['id'],)).fetchone()
                if items and deal:
                    l=db.execute('SELECT product_id FROM listings WHERE id=?',(items[0]['listing_id'],)).fetchone()
                    state['deals'].append(dict(id=o['id'],productId=l[0],sellerId=o['business_id'],amount=total/100,qty=sum(i['quantity'] for i in items),
                       status=deal['status'],buyerOk=bool(deal['buyer_confirmed_at_ms']),sellerOk=bool(deal['seller_confirmed_at_ms']),ts=o['created_at_ms'],
                       items=items,history=history,payments=payments,reviews=reviews,shipment=dict(shipment) if shipment else None,
                       buyer=o['buyer_name_snapshot'],shippingAddress=o['shipping_address_snapshot'],orderStatus=o['status'],
                       isBuyer=o['buyer_id']==uid,canSell=bool(self.membership(db,uid,o['business_id']))))
        ranking=self.rank(catalog['products'],state['activity'])
        return dict(**catalog,categories=categories,state=state,user=user,businesses=businesses,
            ownedListings=owned,businessDocuments=documents,addresses=addresses,recommendations=ranking,
            csrf=session['csrf_token'] if session else None,demo=self.demo(db))

    def route(self,db,uid,path,data):
        stamp=now()
        if path=='/api/settings':
            old=dict(db.execute('SELECT * FROM user_settings WHERE user_id=?',(uid,)).fetchone())
            language=data.get('language',old['language']);theme=data.get('theme',old['theme']);role=data.get('role',old['preferred_role'])
            personalization=data.get('personalization',bool(old['personalization_enabled']))
            require(language in ('en','fr','nl') and theme in (None,'light','dark') and role in ('buyer','seller') and type(personalization) is bool,'Invalid preferences')
            if role=='seller': require(db.execute('SELECT 1 FROM business_members WHERE user_id=?',(uid,)).fetchone(),'Register a business first',403)
            db.execute('UPDATE user_settings SET language=?,theme=?,preferred_role=?,personalization_enabled=? WHERE user_id=?',
                       (language,theme,role,int(personalization),uid))
        elif path=='/api/activity':
            kind=data.get('type'); require(kind in ('view','search'),'Invalid activity type')
            pid=data.get('productId'); category=data.get('cat'); query=data.get('q')
            require(pid is None or isinstance(pid,str),'Invalid product')
            require(category is None or isinstance(category,str),'Invalid category')
            require(query is None or (isinstance(query,str) and len(query)<=300),'Invalid search')
            self.log_event(db,uid,kind,pid,category,query)
        elif path=='/api/privacy/reset':
            db.execute('DELETE FROM recommendation_items WHERE run_id IN (SELECT id FROM recommendation_runs WHERE user_id=?)',(uid,))
            db.execute('DELETE FROM recommendation_runs WHERE user_id=?',(uid,))
            db.execute('DELETE FROM activity_events WHERE user_id=?',(uid,))
            db.execute('UPDATE user_settings SET personalization_enabled=0 WHERE user_id=?',(uid,))
        elif path=='/api/addresses':
            address={k:text(data,k,1,250) for k in ('recipient_name','line1','city','postal_code','country_code')}
            require(len(address['country_code'])==2,'Country must be a two-letter code')
            db.execute('INSERT INTO addresses VALUES (?,?,?,?,?,?,?,?,?)',
                (new_id('addr'),uid,address['recipient_name'],address['line1'],None,address['city'],address['postal_code'],address['country_code'].upper(),stamp))
        elif path=='/api/businesses':
            require(not db.execute('SELECT 1 FROM business_members WHERE user_id=?',(uid,)).fetchone(),'One business per account in this version',409)
            legal=text(data,'legalName',2,200);name=text(data,'name',2,200);number=text(data,'registrationNumber',2,100)
            country=text(data,'country',2,2).upper(); kind=data.get('businessType','company')
            require(kind in ('company','sole_proprietor'),'Invalid business type')
            bid=new_id('biz');vat=data.get('vatNumber') or None;city=data.get('city','')
            require((vat is None or isinstance(vat,str) and len(vat)<=100) and isinstance(city,str) and len(city)<=150,'Invalid business details')
            db.execute('''INSERT INTO businesses (id,legal_name,trading_name,business_type,country_code,
                 registration_number,vat_number,city,created_at_ms,updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?)''',
                 (bid,legal,name,kind,country,number,vat,city,stamp,stamp))
            db.execute('INSERT INTO business_members VALUES (?,?,?)',(bid,uid,'owner'))
            db.execute("UPDATE user_settings SET preferred_role='seller' WHERE user_id=?",(uid,))
            self.audit(db,uid,'business.created','business',bid)
        elif path=='/api/businesses/documents':
            bid=text(data,'businessId');fid=text(data,'fileId');dtype=data.get('type','registration')
            require(self.membership(db,uid,bid),'Not your business',403)
            require(dtype in ('registration','vat','other'),'Invalid document type')
            require(db.execute('SELECT 1 FROM files WHERE id=? AND uploaded_by=?',(fid,uid)).fetchone(),'Not your file',403)
            db.execute('INSERT INTO business_documents VALUES (?,?,?)',(bid,fid,dtype))
        elif path=='/api/cart':
            lid=text(data,'listingId');qty=integer(data,'quantity',0,100)
            if qty==0: db.execute('DELETE FROM cart_items WHERE user_id=? AND listing_id=?',(uid,lid))
            else:
                l=db.execute('''SELECT l.* FROM listings l JOIN businesses b ON b.id=l.business_id
                    JOIN products p ON p.id=l.product_id WHERE l.id=? AND l.status='published'
                    AND b.verification_status='verified' AND p.status='active' ''',(lid,)).fetchone()
                require(l,'Listing is unavailable',409);require(qty<=l['stock'],'Not enough stock',409)
                require(not self.membership(db,uid,l['business_id']),'You cannot buy from your own business')
                db.execute('''INSERT INTO cart_items VALUES (?,?,?,?) ON CONFLICT(user_id,listing_id)
                    DO UPDATE SET quantity=excluded.quantity''',(uid,lid,qty,stamp))
                self.log_event(db,uid,'cart',l['product_id'])
        elif path=='/api/favorites':
            pid=text(data,'productId');want=data.get('favorite')
            require(type(want) is bool,'favorite must be boolean')
            require(db.execute('SELECT 1 FROM products WHERE id=?',(pid,)).fetchone(),'Unknown product',404)
            if want:
                db.execute('INSERT OR IGNORE INTO favorites VALUES (?,?,?)',(uid,pid,stamp));self.log_event(db,uid,'fav',pid)
            else: db.execute('DELETE FROM favorites WHERE user_id=? AND product_id=?',(uid,pid))
        elif path=='/api/listings':
            bid=text(data,'businessId');require(self.membership(db,uid,bid),'Not your business',403)
            title=text(data,'title',2,200);brand=text(data,'brand',0,100);desc=text(data,'description',0,10000)
            cat=text(data,'category');require(db.execute('SELECT 1 FROM categories WHERE id=?',(cat,)).fetchone(),'Unknown category')
            price=integer(data,'priceMinor',1,100000000);stock=integer(data,'stock',0,1000000);days=integer(data,'deliveryDays',0,60)
            cond=data.get('condition','new');status=data.get('status','draft');emoji=data.get('emoji','📦')
            require(cond in ('new','used','refurbished') and status in ('draft','published'),'Invalid listing fields')
            require(isinstance(emoji,str) and len(emoji)<=12,'Invalid icon')
            fileid=data.get('fileId')
            if fileid:
                require(db.execute("SELECT 1 FROM files WHERE id=? AND uploaded_by=? AND mime_type IN ('image/png','image/jpeg','image/webp')",(fileid,uid)).fetchone(),'Invalid product image')
            pid,lid=new_id('p'),new_id('l')
            db.execute('INSERT INTO products VALUES (?,?,?,?,?,?,?,?,?,?,?)',(pid,cat,brand,title,desc,None,None,emoji,'active',stamp,stamp))
            db.execute('''INSERT INTO listings (id,product_id,business_id,price_minor,stock,condition,
                    delivery_days,status,created_at_ms,updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?)''',
                    (lid,pid,bid,price,stock,cond,days,status,stamp,stamp))
            if fileid: db.execute('INSERT INTO product_files VALUES (?,?,?,?)',(pid,fileid,0,title))
            self.audit(db,uid,'listing.created','listing',lid)
        elif path=='/api/listings/update':
            lid=text(data,'listingId');l=db.execute('SELECT * FROM listings WHERE id=?',(lid,)).fetchone()
            require(l,'Listing not found',404);require(self.membership(db,uid,l['business_id']),'Not your listing',403)
            price=integer(data,'priceMinor',1,100000000);stock=integer(data,'stock',0,1000000);status=data.get('status')
            require(status in ('draft','published','paused','archived'),'Invalid listing status')
            db.execute('UPDATE listings SET price_minor=?,stock=?,status=?,updated_at_ms=? WHERE id=?',(price,stock,status,stamp,lid))
            self.audit(db,uid,'listing.updated','listing',lid)
        elif path=='/api/checkout':
            return self.checkout(db,uid,data)
        elif path=='/api/orders/action':
            self.order_action(db,uid,data)
        elif path=='/api/conversations':
            bid=text(data,'businessId');pid=text(data,'productId')
            require(not self.membership(db,uid,bid),'Seller replies inside an existing buyer conversation')
            require(db.execute("SELECT 1 FROM listings WHERE business_id=? AND product_id=? AND status='published'",(bid,pid)).fetchone(),'Listing unavailable',404)
            row=db.execute('SELECT id FROM conversations WHERE buyer_id=? AND business_id=? AND product_id=?',(uid,bid,pid)).fetchone()
            cid=row[0] if row else new_id('conv')
            if not row:
                db.execute('INSERT INTO conversations VALUES (?,?,?,?,?,?)',(cid,uid,bid,pid,None,stamp))
                db.execute('INSERT INTO conversation_participants VALUES (?,?,?)',(cid,uid,stamp))
                for m in db.execute('SELECT user_id FROM business_members WHERE business_id=?',(bid,)):
                    db.execute('INSERT INTO conversation_participants VALUES (?,?,?)',(cid,m[0],None))
                db.execute('INSERT INTO messages (id,conversation_id,kind,body,created_at_ms) VALUES (?,?,?,?,?)',
                           (new_id('msg'),cid,'system','Conversation opened',stamp))
            return {'conversationId':cid}
        elif path in ('/api/messages','/api/conversations/read'):
            cid=text(data,'conversationId');self.require_conversation(db,uid,cid)
            if path=='/api/messages':
                body=text(data,'body',0,5000);fid=data.get('fileId')
                require(body or fid,'Message is empty')
                if fid: require(db.execute('SELECT 1 FROM files WHERE id=? AND uploaded_by=?',(fid,uid)).fetchone(),'Not your file',403)
                mid=new_id('msg')
                db.execute('''INSERT INTO messages (id,conversation_id,sender_user_id,kind,body,created_at_ms)
                    VALUES (?,?,?,?,?,?)''',(mid,cid,uid,'file' if fid else 'text',body,stamp))
                if fid: db.execute('INSERT INTO message_files VALUES (?,?)',(mid,fid))
            db.execute('UPDATE conversation_participants SET last_read_at_ms=? WHERE conversation_id=? AND user_id=?',(stamp,cid,uid))
        elif path=='/api/reviews':
            item=text(data,'orderItemId');rating=integer(data,'rating',1,5);body=text(data,'body',0,2000)
            db.execute('INSERT INTO reviews VALUES (?,?,?,?,?,?)',(new_id('rev'),item,uid,rating,body,stamp))
        elif path=='/api/files':
            filename=text(data,'name',1,200);encoded=text(data,'base64',0,MAX_BODY)
            try: content=base64.b64decode(encoded,validate=True)
            except (ValueError,base64.binascii.Error): raise APIError(400,'Invalid file encoding')
            require(0<len(content)<=MAX_FILE,'File must be between 1 byte and 5 MB',413)
            claimed=data.get('mime','application/octet-stream')
            if content.startswith(b'\x89PNG\r\n\x1a\n'):mime='image/png'
            elif content.startswith(b'\xff\xd8\xff'):mime='image/jpeg'
            elif content[:4]==b'RIFF' and content[8:12]==b'WEBP':mime='image/webp'
            elif content.startswith(b'%PDF-'):mime='application/pdf'
            else:mime='application/octet-stream'
            require(not (isinstance(claimed,str) and claimed.startswith('image/')) or mime.startswith('image/'),'Unsupported or invalid image')
            fid=new_id('f')
            db.execute('INSERT INTO files VALUES (?,?,?,?,?,?,?,?,?,?)',
                (fid,uid,filename,mime,len(content),hashlib.sha256(content).hexdigest(),'database',None,content,stamp))
            return {'fileId':fid}
        else:
            raise APIError(404,'Unknown endpoint')
        return {'ok':True}

    def require_conversation(self,db,uid,cid):
        c=db.execute('SELECT * FROM conversations WHERE id=?',(cid,)).fetchone()
        require(c,'Conversation not found',404)
        require(c['buyer_id']==uid or self.membership(db,uid,c['business_id']),'No access to this conversation',403)
        require(db.execute('SELECT 1 FROM conversation_participants WHERE conversation_id=? AND user_id=?',(cid,uid)).fetchone(),'Not a conversation participant',403)
        return c

    def checkout(self,db,uid,data):
        require(self.demo(db),'Live payment provider is not configured; checkout is disabled',503)
        key=text(data,'requestKey',8,100)
        old=db.execute('SELECT order_ids_json FROM checkout_requests WHERE user_id=? AND request_key=?',(uid,key)).fetchone()
        if old:return {'orderIds':json.loads(old[0]),'replayed':True}
        buyer=db.execute('SELECT display_name FROM users WHERE id=?',(uid,)).fetchone()[0]
        address_id=text(data,'addressId')
        address=db.execute('SELECT * FROM addresses WHERE id=? AND user_id=?',(address_id,uid)).fetchone()
        require(address,'Select your saved delivery address')
        address_snapshot='\n'.join(address[k] for k in ('recipient_name','line1','city','postal_code','country_code'))
        rows=db.execute('''SELECT l.*,c.quantity,p.title,p.status AS product_status,b.trading_name,
              b.verification_status FROM cart_items c JOIN listings l ON l.id=c.listing_id
              JOIN products p ON p.id=l.product_id JOIN businesses b ON b.id=l.business_id
              WHERE c.user_id=?''',(uid,)).fetchall()
        require(rows,'Your cart is empty')
        groups=defaultdict(list)
        for l in rows:
            require(l['status']=='published' and l['product_status']=='active' and l['verification_status']=='verified','A listing is no longer available',409)
            require(not self.membership(db,uid,l['business_id']),'Cannot order from your own business')
            groups[l['business_id']].append(l)
        order_ids=[];stamp=now()
        for bid,items in groups.items():
            oid=new_id('order');shipping=max(l['shipping_minor'] for l in items)
            db.execute('''INSERT INTO orders (id,buyer_id,business_id,buyer_name_snapshot,
                 merchant_name_snapshot,shipping_address_snapshot,shipping_minor,status,
                 created_at_ms,updated_at_ms) VALUES (?,?,?,?,?,?,?,?,?,?)''',
                 (oid,uid,bid,buyer,items[0]['trading_name'],address_snapshot,shipping,'paid',stamp,stamp))
            for l in items:
                changed=db.execute('UPDATE listings SET stock=stock-?,updated_at_ms=? WHERE id=? AND stock>=?',
                    (l['quantity'],stamp,l['id'],l['quantity'])).rowcount
                require(changed==1,'Not enough stock; nothing has been charged',409)
                db.execute('INSERT INTO order_items VALUES (?,?,?,?,?,?,?,?)',
                    (new_id('item'),oid,bid,l['id'],l['title'],None,l['quantity'],l['price_minor']))
                self.log_event(db,uid,'deal',l['product_id'])
            amount=db.execute('SELECT total_minor FROM order_totals WHERE order_id=?',(oid,)).fetchone()[0]
            self.demo_payment(db,oid,'charge',amount,'charge:'+oid)
            db.execute('INSERT INTO secure_deals VALUES (?,?,?,?,?,?,?)',(new_id('deal'),oid,'held',None,None,None,stamp))
            db.execute('INSERT INTO order_status_history VALUES (?,?,?,?,?,?)',(new_id('h'),oid,'paid',uid,'DEMO payment; no real money moved',stamp))
            self.audit(db,uid,'order.created','order',oid);order_ids.append(oid)
        db.execute('DELETE FROM cart_items WHERE user_id=?',(uid,))
        db.execute('INSERT INTO checkout_requests VALUES (?,?,?,?)',(uid,key,json.dumps(order_ids),stamp))
        return {'orderIds':order_ids,'replayed':False}

    @staticmethod
    def demo_payment(db,oid,kind,amount,key):
        stamp=now()
        related=db.execute("SELECT id FROM payment_transactions WHERE order_id=? AND kind='charge' AND status='succeeded'",(oid,)).fetchone()
        db.execute('''INSERT INTO payment_transactions (id,order_id,kind,amount_minor,provider,
             provider_reference,idempotency_key,related_transaction_id,status,created_at_ms,updated_at_ms)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
             (new_id('pay'),oid,kind,amount,'DEMO',new_id('demo'),key,related[0] if related else None,'succeeded',stamp,stamp))

    def order_action(self,db,uid,data):
        oid=text(data,'orderId');action=data.get('action')
        o=db.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
        require(o,'Order not found',404)
        is_buyer=o['buyer_id']==uid;is_seller=bool(self.membership(db,uid,o['business_id']))
        require(is_buyer or is_seller,'No access to this order',403)
        d=db.execute('SELECT * FROM secure_deals WHERE order_id=?',(oid,)).fetchone()
        require(d,'Deal not found',404)
        require(self.demo(db),'Live provider is not configured',503)
        stamp=now();status=o['status'];note=''
        if action=='ship':
            require(is_seller,'Only this merchant can confirm shipment',403)
            if d['seller_confirmed_at_ms']:return
            require(d['status']=='held' and status=='paid','Order cannot be shipped',409)
            carrier=text(data,'carrier',0,100);tracking=text(data,'tracking',0,150)
            db.execute('UPDATE secure_deals SET seller_confirmed_at_ms=? WHERE order_id=?',(stamp,oid))
            db.execute('INSERT INTO shipments VALUES (?,?,?,?,?,?)',(new_id('ship'),oid,carrier,tracking,stamp,None))
            status='shipped';note='Merchant confirmed dispatch'
        elif action=='receive':
            require(is_buyer,'Only the buyer can confirm receipt',403)
            if d['buyer_confirmed_at_ms']:return
            require(d['status']=='held' and d['seller_confirmed_at_ms'] is not None,'Wait until the seller ships',409)
            db.execute("UPDATE secure_deals SET buyer_confirmed_at_ms=?,released_at_ms=?,status='completed' WHERE order_id=?",(stamp,stamp,oid))
            db.execute('UPDATE shipments SET delivered_at_ms=? WHERE order_id=?',(stamp,oid))
            total=db.execute('SELECT total_minor FROM order_totals WHERE order_id=?',(oid,)).fetchone()[0]
            self.demo_payment(db,oid,'payout',total,'payout:'+oid)
            status='completed';note='DEMO receipt confirmed; simulated payout'
        elif action=='cancel':
            if d['status']=='cancelled':return
            require(d['status']=='held' and not d['seller_confirmed_at_ms'],'Only unshipped orders can be cancelled',409)
            for item in db.execute('SELECT listing_id,quantity FROM order_items WHERE order_id=?',(oid,)):
                db.execute('UPDATE listings SET stock=stock+?,updated_at_ms=? WHERE id=?',(item['quantity'],stamp,item['listing_id']))
            db.execute("UPDATE secure_deals SET status='cancelled' WHERE order_id=?",(oid,))
            total=db.execute('SELECT total_minor FROM order_totals WHERE order_id=?',(oid,)).fetchone()[0]
            self.demo_payment(db,oid,'refund',total,'refund:'+oid)
            status='cancelled';note='DEMO cancellation; simulated refund'
        else:raise APIError(400,'Unknown order action')
        db.execute('UPDATE orders SET status=?,updated_at_ms=? WHERE id=?',(status,stamp,oid))
        db.execute('INSERT INTO order_status_history VALUES (?,?,?,?,?,?)',(new_id('h'),oid,status,uid,note,stamp))
        self.audit(db,uid,'order.'+action,'order',oid)

    def file(self,db,uid,fid):
        f=db.execute('SELECT * FROM files WHERE id=?',(fid,)).fetchone()
        require(f,'File not found',404)
        public=db.execute('''SELECT 1 FROM product_files pf JOIN products p ON p.id=pf.product_id
             JOIN listings l ON l.product_id=p.id JOIN businesses b ON b.id=l.business_id
             WHERE pf.file_id=? AND l.status='published' AND p.status='active'
             AND b.verification_status='verified' ''',(fid,)).fetchone()
        allowed=bool(public and f['mime_type'].startswith('image/'))
        if uid:
            allowed=allowed or f['uploaded_by']==uid
            allowed=allowed or bool(db.execute('''SELECT 1 FROM message_files mf JOIN messages m ON m.id=mf.message_id
                JOIN conversations c ON c.id=m.conversation_id WHERE mf.file_id=? AND
                (c.buyer_id=? OR EXISTS(SELECT 1 FROM business_members bm WHERE bm.business_id=c.business_id AND bm.user_id=?))''',(fid,uid,uid)).fetchone())
            allowed=allowed or bool(db.execute('''SELECT 1 FROM business_documents d JOIN business_members m ON m.business_id=d.business_id WHERE d.file_id=? AND m.user_id=?''',(fid,uid)).fetchone())
        require(allowed,'File is private',403)
        return f


class Handler(BaseHTTPRequestHandler):
    server_version='Marketplace/1.0'
    rate_lock=threading.Lock()
    rate=defaultdict(deque)

    def log_message(self,fmt,*args):
        # Do not log query strings, payloads, cookies or credentials.
        print(f'{self.client_address[0]} {self.command} {urlsplit(self.path).path}')

    def security_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'nonce-"+self.nonce+"'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")

    def respond(self,status,payload,ctype='application/json; charset=utf-8',extra=None):
        content=json.dumps(payload,ensure_ascii=False).encode() if 'application/json' in ctype else payload
        self.send_response(status);self.security_headers();self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(content)))
        for k,v in (extra or {}).items():self.send_header(k,v)
        self.end_headers();self.wfile.write(content)

    def valid_host(self):
        host=self.headers.get('Host','')
        require(bool(host) and urlsplit('//'+host).hostname in self.server.allowed_hosts,'Host is not allowed',403)
        return host

    def token(self):
        jar=cookies.SimpleCookie()
        try:jar.load(self.headers.get('Cookie',''))
        except cookies.CookieError:return None
        return jar['market_session'].value if 'market_session' in jar else None

    def cookie(self,token='',logout=False):
        return 'market_session='+token+'; Path=/; HttpOnly; SameSite=Strict; Max-Age='+('0' if logout else str(SESSION_MS//1000))+('; Secure' if self.server.secure_cookie else '')

    def limit(self):
        key=self.client_address[0];clock=time.monotonic()
        with self.rate_lock:
            events=self.rate[key]
            while events and events[0]<clock-60:events.popleft()
            require(len(events)<12,'Too many authentication attempts; retry in a minute',429)
            events.append(clock)

    def dispatch(self):
        self.nonce=secrets.token_urlsafe(18)
        try:
            host=self.valid_host();path=unquote(urlsplit(self.path).path)
            if self.command=='GET':return self.get(path)
            require(self.command=='POST','Method not allowed',405)
            origin=self.headers.get('Origin')
            expected=self.server.public_origin or ('http://'+host)
            require(origin==expected,'Origin check failed',403)
            require(self.headers.get('Content-Type','').split(';')[0]=='application/json','JSON required',415)
            try:length=int(self.headers.get('Content-Length','0'))
            except ValueError:raise APIError(400,'Invalid content length')
            require(0<length<=MAX_BODY,'Request too large or empty',413)
            try:data=json.loads(self.rfile.read(length))
            except (json.JSONDecodeError,UnicodeDecodeError):raise APIError(400,'Invalid JSON')
            require(isinstance(data,dict),'JSON object required')
            app=self.server.app
            with app.connection(write=True) as db:
                session=app.session(db,self.token())
                if path in ('/api/auth/register','/api/auth/login'):
                    self.limit()
                    email=text(data,'email',3,254).lower()
                    require(bool(re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email)),'Invalid email')
                    password=data.get('password')
                    require(isinstance(password,str) and 12<=len(password)<=128,'Password must contain 12–128 characters')
                    if path.endswith('register'):
                        require(not db.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone(),'Account already exists',409)
                        uid=create_user(db,email,text(data,'name',1,120),password)
                    else:
                        u=db.execute('''SELECT u.*,c.salt,c.password_hash FROM users u JOIN auth_credentials c ON c.user_id=u.id WHERE u.email=?''',(email,)).fetchone()
                        computed=password_hash(password,u['salt'] if u else '00'*16)
                        require(u and u['status']=='active' and hmac.compare_digest(computed,u['password_hash']),'Invalid email or password',401)
                        uid=u['id']
                    # Drop the current session on account change; never accept a browser-provided user ID.
                    if session:db.execute('DELETE FROM auth_sessions WHERE token_hash=?',(session['token_hash'],))
                    token,csrf=app.new_session(db,uid)
                    result={'ok':True,'csrf':csrf};extra={'Set-Cookie':self.cookie(token)}
                else:
                    require(session,'Sign in first',401)
                    require(hmac.compare_digest(self.headers.get('X-CSRF-Token',''),session['csrf_token']),'CSRF token mismatch',403)
                    if path=='/api/auth/logout':
                        db.execute('DELETE FROM auth_sessions WHERE token_hash=?',(session['token_hash'],))
                        result={'ok':True};extra={'Set-Cookie':self.cookie(logout=True)}
                    else:
                        result=app.route(db,session['user_id'],path,data);extra=None
            self.respond(200,result,extra=extra)
        except APIError as e:self.respond(e.status,{'error':e.message})
        except sqlite3.IntegrityError as e:
            message=str(e)
            safe=message if message.startswith(('Only verified','Review requires')) else 'Data conflicts with an existing record or database constraint'
            self.respond(409,{'error':safe})
        except sqlite3.OperationalError:
            self.respond(503,{'error':'Database is busy or unavailable; retry later'})
        except (BrokenPipeError,ConnectionResetError):pass
        except Exception as e:
            print('Server error:',type(e).__name__)
            self.respond(500,{'error':'Unexpected server error'})

    def get(self,path):
        app=self.server.app
        if path=='/health':return self.respond(200,{'ok':True})
        if path=='/api/bootstrap':
            with app.connection() as db:result=app.bootstrap(db,app.session(db,self.token()))
            return self.respond(200,result)
        if path.startswith('/api/files/'):
            with app.connection() as db:
                s=app.session(db,self.token());f=app.file(db,s['user_id'] if s else None,path.removeprefix('/api/files/'))
            disposition='inline' if f['mime_type'].startswith('image/') else 'attachment'
            # Fixed safe filename; the original filename remains in the API metadata.
            return self.respond(200,f['content'],f['mime_type'],{'Content-Disposition':disposition+'; filename="download"'})
        paths={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/app.css':'app.css'}
        require(path in paths,'Not found',404)
        filename=paths[path];content=(ROOT/'web'/filename).read_bytes()
        if filename.endswith('.html'):content=content.replace(b'<script>',('<script nonce="'+self.nonce+'">').encode())
        ctype={'html':'text/html; charset=utf-8','js':'text/javascript; charset=utf-8','css':'text/css; charset=utf-8'}[filename.split('.')[-1]]
        self.respond(200,content,ctype)

    do_GET=dispatch
    do_POST=dispatch


def make_server(db_path,host='127.0.0.1',port=8000):
    server=ThreadingHTTPServer((host,port),Handler)
    server.app=Marketplace(db_path)
    server.public_origin=os.environ.get('PUBLIC_ORIGIN','').rstrip('/')
    server.secure_cookie=server.public_origin.startswith('https://')
    server.allowed_hosts={'localhost','127.0.0.1','::1'}
    if server.public_origin:server.allowed_hosts.add(urlsplit(server.public_origin).hostname)
    return server


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',default=os.environ.get('DATABASE_PATH',str(ROOT/'data/marketplace.sqlite')))
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8000)
    args=parser.parse_args()
    path=Path(args.db)
    if not path.exists():initialize(path,demo=True)
    else:initialize(path)
    with Marketplace(path).connection() as db:mode='DEMO (no real money or registry verification)' if Marketplace.demo(db) else 'LIVE STORAGE; checkout disabled'
    print(f'Marketplace at http://{args.host}:{args.port} — {mode}',flush=True)
    server=make_server(path,args.host,args.port)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()


if __name__=='__main__':main()
