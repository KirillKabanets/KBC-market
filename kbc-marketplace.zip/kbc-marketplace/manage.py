import argparse
from pathlib import Path
from server import ROOT, Marketplace, initialize, now
p=argparse.ArgumentParser();p.add_argument('command',choices=['init-demo','init-empty','approve-business','backup']);p.add_argument('--db',default=str(ROOT/'data/marketplace.sqlite'));p.add_argument('--business');p.add_argument('--reference');p.add_argument('--output');a=p.parse_args();path=Path(a.db)
if a.command.startswith('init-'):initialize(path,demo=a.command=='init-demo');print('Database ready:',path)
elif a.command=='approve-business':
    if not a.business or not a.reference:p.error('--business and --reference are required after independently checking the business')
    with Marketplace(path).connection(write=True) as db:
        n=db.execute("UPDATE businesses SET verification_status='verified',verified_at_ms=?,verification_reference=?,updated_at_ms=? WHERE id=?",(now(),a.reference,now(),a.business)).rowcount
        if not n:p.error('Business not found')
    print('Business approved')
else:
    import sqlite3
    if not a.output:p.error('--output is required')
    with sqlite3.connect(path) as source,sqlite3.connect(a.output) as dest:source.backup(dest)
    print('Backup saved')
