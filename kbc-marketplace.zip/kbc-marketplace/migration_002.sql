-- Runtime additions to the original schema. Run by manage.py / server.py once.
PRAGMA foreign_keys=ON;
BEGIN IMMEDIATE;
CREATE TABLE auth_credentials (
    user_id TEXT PRIMARY KEY REFERENCES users(id),
    salt TEXT NOT NULL,
    password_hash TEXT NOT NULL
) STRICT;
CREATE TABLE auth_sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    csrf_token TEXT NOT NULL,
    created_at_ms INTEGER NOT NULL,
    expires_at_ms INTEGER NOT NULL
) STRICT;
CREATE INDEX sessions_user ON auth_sessions(user_id);
CREATE INDEX sessions_expiry ON auth_sessions(expires_at_ms);
CREATE TABLE app_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL) STRICT;
CREATE TABLE checkout_requests (
    user_id TEXT NOT NULL REFERENCES users(id),
    request_key TEXT NOT NULL,
    order_ids_json TEXT NOT NULL,
    created_at_ms INTEGER NOT NULL,
    PRIMARY KEY(user_id,request_key)
) STRICT;
CREATE TRIGGER conversation_members_update
BEFORE UPDATE ON conversation_participants
BEGIN
    SELECT RAISE(ABORT,'Invalid conversation participant')
    WHERE NOT EXISTS(SELECT 1 FROM conversations c WHERE c.id=NEW.conversation_id
      AND (c.buyer_id=NEW.user_id OR EXISTS(SELECT 1 FROM business_members b
           WHERE b.business_id=c.business_id AND b.user_id=NEW.user_id)));
END;
CREATE TRIGGER reviews_update_requires_completed_purchase
BEFORE UPDATE ON reviews
BEGIN
    SELECT RAISE(ABORT,'Review requires a completed purchase by its author')
    WHERE NOT EXISTS(SELECT 1 FROM order_items i JOIN orders o ON o.id=i.order_id
      WHERE i.id=NEW.order_item_id AND o.buyer_id=NEW.author_id AND o.status='completed');
END;
INSERT INTO schema_migrations VALUES (2,CAST(strftime('%s','now') AS INTEGER)*1000);
COMMIT;
